#ifndef FILE_SPECIALS
#define FILE_SPECIALS

/*

  Very special implementations ..
  
 */


///
extern void CutOffAndCombine (Mesh & mesh, const Mesh & othermesh);

extern void HelmholtzMesh (Mesh & mesh);

#endif
