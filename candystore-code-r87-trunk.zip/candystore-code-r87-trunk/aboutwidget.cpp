#include "aboutwidget.h"

aboutwidget::aboutwidget()
{
}
