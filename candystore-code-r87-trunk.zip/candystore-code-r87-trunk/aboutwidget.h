#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <QWidget>

class aboutwidget : public QWidget
{
public:
    aboutwidget();
};

#endif // ABOUTWIDGET_H
