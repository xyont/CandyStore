#ifndef MATHEMATICS_H
#define MATHEMATICS_H
#define NMAXGAUSS 10


class mathematics
{
public:
    mathematics();
    static int Gaussalg (double a[][NMAXGAUSS], int n, double x[]);
};

#endif // MATHEMATICS_H
