/***************************************************************************
 *   Copyright (C) 2008 by Patrick Prokopczuk   *
 *   prokopczuk@gmx.de   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/**
 * \file quaternion.h
 * \brief Basic quaternion class with fundamental quaternion operations
 **/
#ifndef QUATERNION_H
 #define QUATERNION_H
 
#include "../vector3d/vector3d.h"

class quaternion  
{
	
public:
 union
  {
    struct { double w, x, y, z; };
    double c[4];
  };
//****************************************************************************************
  /*! Default constructor constructs a zero- quaternion. */
  quaternion() : w(0.0), x(0.0), y(0.0), z(0.0) {}
  //****************************************************************************************
  /*! Value Constructor */
  quaternion(double a,double b, double c, double d) 
  {
	w=a;
	x=b;
	y=c;
	z=d;
  }
//*****************************************************************************************
 /*!  Return quaternion values via index (0,1,2,3)*/
 double operator[](int i) const {
    return c[i];
  }
//****************************************************************************************
   /*! Acces quaternion  via index mode (0,1,2,3).  (lvalue)*/
  double& operator[](int i) {
    return c[i];
  }
//****************************************************************************************
   /*!  Returning the memory address of the quaternion.
*/
  operator const double*() const {
    return c;
  }
//*****************************************************************************************
//*****************************************************************************************
/*! Sets all components of the quaternion to zero*/
void zero()
{
    w=1.0;
	x=0.0;
	y=0.0;
    z=0.0;
}
//******************************************************************************************
/*! Adds two quaternions*/ 
friend quaternion operator+(const quaternion &a, const quaternion &b)
{
    /*quaternion  q1,q2,q3;
	vector3d v1,v2,v3;
	
    q1=a;
    q1= q1*b[3];

    q2=b;
    q2=q2*a[3];

	v1.x=a.w;
	v1.y=a.x;
	v1.z=a.y;
	
	v2.x=b.w;
	v2.y=b.x;
	v2.z=b.y;
	
    v3=cross(v1,v2);
    
	q3.w=q1.w+q2.w+v3.x;
	q3.x=q1.x+q2.x+v3.y;
	q3.y=q1.y+q2.y+v3.z;
    q3.z=a.z * b.z - (v1*v2);

    q3.normalize();
	return(q3);
    */
    quaternion q1;
    q1.w=a.w+b.w;
    q1.x=a.x+b.x;
    q1.y=a.y+b.y;
    q1.z=a.z+b.z;
    return(q1);
}
//*********************************************
/*! Adds two quaternions*/
friend quaternion operator*(const quaternion &a, const quaternion &b)
{

//Multiply two quaternions (== Adding rotations)

/*q*r = (a + bi+ cj + dk)*(e + fi+ gj + hk) =
    = ae + afi + agj + ahk
      + bie + bifi + bigj + bihk
      + cje + cjfi + cjgj + cjhk
      + dke + dkfi + dkgj + dkhk
    = (a * e - b * f  - c * g - d * h)
      + (a * f + b * e + c * h - d * g)i
      + (a * g - b * h + c * e + d * f)j
      + (a * h + b * g - c * f + d * e)k*/
quaternion q;

q[0]=a[0]*b[0]-(a[1]*b[1])-(a[2]*b[2])-a[3]*b[3];
q[1]=a[0]*b[1]+(a[1]*b[0])+(a[2]*b[3])-a[3]*b[2];
q[2]=a[0]*b[2]-(a[1]*b[3])+(a[2]*b[0])+a[3]*b[1];
q[3]=a[0]*b[3]+(a[1]*b[2])-(a[2]*b[1])+a[3]*b[0];

return(q);
}
//*******************************************************************************************
/*! =-operator*/
quaternion& operator=(const quaternion& v)
  {
    x = v.x;   y = v.y;   z = v.z; w =v.w;
    return *this;
  }
//*******************************************************************************************
/*!Multiplies a quaternion with skalar*/
friend quaternion operator*(const quaternion &a, float k)
  {
    return quaternion(a.w*k,a.x*k, a.y*k, a.z*k);
  }
 //******************************************************************************************
/*!Normalizes a quaternion*/
void normalize()
{
    double mag;

    mag = (w*w + x*x + y*y + z*z);
    
	w /= mag;
	x /= mag;
	y /= mag;
	z /= mag;
}
};
#endif

