/***************************************************************************
 *   Copyright (C) 2008 by Patrick Prokopczuk   *
 *   prokopczuk@gmx.de   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
 /**
 * \file trackball.cpp
 **/
 #include "trackball.h"
 
 //!   Trackball for view manipulation
/*! 
	The trackball is used to convert a mouse translation on the screen
	into a rotation. A vitual trackball is used. The start and end point of the mouse translation
	are projected onto the virtual a trackball and the resulting rotation is computed
 */
/*! Standard Constructor*/
 trackball::trackball(QWidget *parent)
    	:QObject(parent)
{
	q1.zero();
	v1.zero();
	v2.zero();
	axis.zero();
	q1.zero();
	radius=600;
}
//***********************************************************************************
/*!Calculate a quaternion from the trackball rotation defined by two screen points*/

quaternion trackball::calcQuat(QPoint p1, QPoint p2,int w, int h)
{
	double l,alpha;

	v1.x=static_cast<double>(p1.x())-(static_cast<double>(w)/2);
	v1.y=-1*(static_cast<double>(p1.y())-(static_cast<double>(h)/2));
	v2.x=static_cast<double>(p2.x())-(static_cast<double>(w)/2);
	v2.y=-1*(static_cast<double>(p2.y())-(static_cast<double>(h)/2));
	v1.z=0.0;
	v2.z=0.0;
	
	//check wether a rotation exists. If not return a no rotation quat 
	if (v1==v2) 
	{
		q1.zero();
		return(q1);
	}
	
	v1.z=calcSphereZCoord(v1.x,v1.y,radius);
	v2.z=calcSphereZCoord(v2.x,v2.y,radius);
	
	axis=cross(v1,v2-v1);
	axis.normalize();
	
	l=(v1-v2).norm()/(0.5*radius);
	
	if (l > 1.0) l = 1.0;
    if (l < -1.0) l = -1.0;
    alpha = 2.0 * asin(l);
	
	//Calculate the quaternion
    q1.x=axis.x*sin(alpha/2.0);
    q1.y=axis.y*sin(alpha/2.0);
    q1.z=axis.z*sin(alpha/2.0);
    q1.w=cos(alpha/2.0);
	
	q1.normalize();
	
	return(q1);
}
//***************************************************************************************
/*! Calculate the z values of a sphereof radius r when x and coords are given*/
double trackball::calcSphereZCoord(double x, double y, double r)
{
	double dist, z;

    dist = sqrt(x*x + y*y);
    if (dist < r*0.70710678118654) 
	{    
        z = sqrt(r*r - dist*dist);
    } 
	else 
	{
        z = ((r / 1.4142135623730950)*(r / 1.4142135623730950)) / dist;
    }
    return(z);
	
}
