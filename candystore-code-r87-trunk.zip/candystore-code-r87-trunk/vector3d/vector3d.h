/***************************************************************************
 *   Copyright (C) 2008 by Patrick Prokopczuk   *
 *   prokopczuk@gmx.de   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

# ifndef VECTOR3D_H
# define VECTOR3D_H

#include <math.h>

#define vector3d_ZERO 1.0E-9
/*! Basic 3D-vector class with fundamental vector operations. */              

class vector3d
{
public:
  /*!  Coordinates can be accessed via x,y,z or []  operator*/
  union
  {
    struct { double x, y, z; };
    double c[3];
  };
//****************************************************************************************
  /*! Default constructor constructs a zero- vector. */
  vector3d() : x(0.0), y(0.0), z(0.0) {}
//****************************************************************************************
 /*! Constructor with coordinates */
  vector3d(double X, double Y, double Z) : x(X), y(Y), z(Z) {}
//****************************************************************************************
 /*!  Return coordinates via index (0,1,2)*/
 double operator[](int i) const {
    return c[i];
  }
//****************************************************************************************
   /*! Acces vector coordinates via index mode (0,1,2).  (lvalue)*/
  double& operator[](int i) {
    return c[i];
  }
//****************************************************************************************
   /*!  Returning the memory address of the vector.
Useful for passing the vector to openGL functions
*/
  operator const double*() const {
    return c;
  }
//*****************************************************************************************
/*! = operator. */
  vector3d& operator=(const vector3d& v)
  {
    x = v.x;   y = v.y;   z = v.z;
    return *this;
  }
//*******************************************************************************************
  /*! Subtracts vector b from vector a*/
  friend vector3d operator-(const vector3d &a, const vector3d &b)
  {
    return vector3d(a.x-b.x, a.y-b.y, a.z-b.z);
  }
//*****************************************************************************************
/*! Dot product of vector  a and vector b. */
  friend double operator*(const vector3d &a, const vector3d &b)
  {
    return a.x*b.x + a.y*b.y + a.z*b.z;
  }
//*****************************************************************************************
/*! Returns the product of the vector a with a scalar k. */
  friend vector3d operator*(const vector3d &a, float k)
  {
    return vector3d(a.x*k, a.y*k, a.z*k);
  }
//*****************************************************************************************
/*! Returns the product of the vector a with a scalar k. */
  friend vector3d operator*(float k, const vector3d &a)
  {
    return a*k;
  }
//*****************************************************************************************
 /*! Sum of vector a and vector b*/
  friend vector3d operator+(const vector3d &a, const vector3d &b)
  {
    return vector3d(a.x+b.x, a.y+b.y, a.z+b.z);
  }
//*****************************************************************************************
 /*! Division of  vector a by k.
  
 
  friend vector3d operator/(const vector3d &a, float k)
  {
    return vector3d(a.x/k, a.y/k, a.z/k);
  }*/
//*******************************************************************************************
/*! Division of  vector a by k.

 */
 
  friend vector3d operator/(const vector3d &a, double k)
  {
    return vector3d(a.x/k, a.y/k, a.z/k);
  }
//*******************************************************************************************
 /*! Divides the   vector by k.*
 
 vector3d& operator/=(float k)
  {
    x /=k;
	y /=k;
	z /=k;
	return *this;
  }*/
//*******************************************************************************************
/*! Divides the   vector by k.*/
 
 vector3d& operator/=(double k)
  {
    x /=k;
	y /=k;
	z /=k;
	return *this;
  }
//*******************************************************************************************
/*! Checks wether two vectors are equal 

     The two vectors are equal, If the norm of the difference of the two vectors is smaller than vector3d_ZERO 
*/
  friend bool operator==(const vector3d &a, const vector3d &b)
  {
    
   return(a-b).norm() < vector3d_ZERO;
	
  }
//*******************************************************************************************
/*! crossproduct of vector a and vector b 
      
*/
  friend vector3d cross(const vector3d &a, const vector3d &b)
  {
    return vector3d(a.y*b.z - a.z*b.y,
	       a.z*b.x - a.x*b.z,
	       a.x*b.y - a.y*b.x);
  }
//*****************************************************************************************
/*!  Calculates the squared norm of the vector.  
  \f$x^2+y^2+z^2\f$ */ 
  double squaredNorm() const { return (x*x + y*y + z*z); }
//*****************************************************************************************
/*!  Calculates the norm of the vector.  
  \f$\sqrt{x^2+y^2+z^2}\f$ */
  double norm() const { return sqrt(x*x + y*y + z*z); }
//*****************************************************************************************
/*! Reurns the projection of the vector on vector a
      
*/ 
  
  vector3d project(const vector3d &a)
  {
		double k=(*this * a)/squaredNorm();
		return vector3d(a.x*k,a.y*k,a.z*k);
		
  
  }
//**************************************************************************
/*!  Normalizes the vector.  
*      If the vector is a null vector (norm() < vector3d_ZERO) the vector is not modified and function returns -1. \n
*     Otherwise the former norm of the vector is returned.	   
*/
  double normalize()
  {
	double b=norm();
	if (b < vector3d_ZERO)
	{
		return(-1);
	}
	*this /=b;
	return(b);
  }
  
//*****************************************************************************************
/*! angle (degrees) between vector a and vector b \n

       \f$\alpha=\arccos(\frac{\overrightarrow{ a}*\overrightarrow{ b}}{|\overrightarrow{ a}|*|\overrightarrow{ b}|})\f$  */
  static double vecAngle(const vector3d &a, const vector3d &b) 
  {
  double sprodukt;
  double n1,q,an,ang;
  
		sprodukt=a*b;
		n1=a.norm()*b.norm();
		q=sprodukt/n1;
		an=acos(q);
		ang=an*360/(2*3.1415);
    return(ang);
  }
//*****************************************************************************************
/*! angle (radians) between vector a and vector b \n

       \f$\alpha=\arccos(\frac{\overrightarrow{ a}*\overrightarrow{ b}}{|\overrightarrow{ a}|*|\overrightarrow{ b}|})\f$  */
  static double vecRadAngle(const vector3d &a, const vector3d &b) 
  {
  double sprodukt;
  double n1,q,an,ang;
  
		sprodukt=a*b;
		n1=a.norm()*b.norm();
		q=sprodukt/n1;
		an=acos(q);
    return(ang);
  }
//*****************************************************************************************
/*! Sets all components of the vector to zero*/
void zero()
{
	x=0;
	y=0;
	z=0;
}
//******************************************************************************************
//*****************************************************************************************
/*! Rotates the vector around another vector*/
vector3d rotate(vector3d &n, double degree)
{
	//degree in rad umrechnen!!
	double d=degree/360*2*3.1415;
	n.normalize();
	vector3d temp;
	temp=cross(*this,n);
	return(*this * cos(d)+(1-cos(d))*(n * *this)*n+(temp)*sin(d));
	
	
}
//******************************************************************************************
//*****************************************************************************************
/*! Returns an orthogonal vector*/
vector3d orthoVec()
{
	vector3d temp;
	if (z < 1e-15)
	{
		if(x < 1e-15)
		{
			temp.zero();
			temp.x=1;
			return(temp);
		}
		else
		{
			temp.y=1;
			temp.z=1;
			temp.x=((-y-z)/x);
			temp.normalize();
			return(temp);
		}
			
		
	}
	temp.x=1;
	temp.y=1;
	temp.z=((-x-y)/z);
	temp.normalize();
	return(temp);
}
//******************************************************************************************
};

#endif 
